/**
 * @file genetic-algorithm.h
 *
 * @author     Christophe Demko <christophe.demko@univ-lr.fr>
 * @date       2019-2023
 * @copyright  BSD 3-Clause License
 */
#ifndef GENETIC_ALGORITHM_H_
#define GENETIC_ALGORITHM_H_

#include <stdbool.h>
#include <stdio.h>

/**
 * @brief The GeneticAlgorithm memory allocation function.
 */
extern void *(*ga_malloc)(size_t size);
/**
 * @brief The GeneticAlgorithm memory array like allocation function.
 */
extern void *(*ga_calloc)(size_t nmemb, size_t size);
/**
 * @brief The GeneticAlgorithm memory reallocation function.
 */
extern void *(*ga_realloc)(void *ptr, size_t size);
/**
 * @brief The GeneticAlgorithm memory free function.
 */
extern void (*ga_free)(void *ptr);

/**
 * @brief Initialise the GeneticAlgorithm module.
 *
 * @return True if the module was initialized successfully, false otherwise.
 *
 * @note This function must be called before any other function in the module.
 * @note This function can be called multiple times, but must be called the same number of times as ga_finish.
 */
extern bool ga_init(void);
/**
 * @brief Finalize the GeneticAlgorithm module.
 *
 * @return True if the module was finalized successfully, false otherwise.
 *
 * @note This function must be called after all other functions in the module.
 * @note This function can be called multiple times, but must be called the same number of times as ga_init.
 */
extern bool ga_finish(void);

/**
 * @brief The GAGenerator structure.
 *
 * @details The GAGenerator structure is used to represent a generator.
 *
 * @see ga_generator_create
 * @see ga_generator_destroy
 */
typedef struct _GAGenerator GAGenerator;

/**
 * @brief Create a new generator.
 *
 * @details Create a new generator of the given size.
 * @details The generator is initialized with all domains set to 1.
 *
 * @param size The size of the generator.
 *
 * @return The new generator.
 *
 * @note The returned generator must be destroyed with ga_generator_destroy.
 */
extern GAGenerator *ga_generator_create(const unsigned int size);
/**
 * @brief Destroy a generator.
 */
extern void ga_generator_destroy(GAGenerator *generator);

/**
 * @brief Set the domain of a generator.
 *
 * @param generator The generator.
 * @param index The index of the domain to set.
 *
 * @param domain The domain to set.
 *
 * @return The generator.
 */
extern GAGenerator *ga_generator_set_domain(GAGenerator *generator, const unsigned int index, const unsigned int domain);
/**
 * @brief Get the domain of a generator.
 *
 * @param generator The generator.
 * @param index The index of the domain to get.
 *
 * @return The domain.
 */
extern unsigned int ga_generator_get_domain(const GAGenerator *generator, const unsigned int index);
/**
 * @brief Get the size of a generator.
 *
 * @param generator The generator.
 *
 * @return The size.
 */
extern unsigned int ga_generator_get_size(const GAGenerator *generator);

/**
 * @brief Clone a generator.
 *
 * @param genetic_generator The generator to clone.
 *
 * @return The clone.
 */
extern GAGenerator *ga_generator_clone(const GAGenerator *genetic_generator);
/**
 * @brief Copy a generator.
 *
 * @param dest The destination generator.
 * @param src The source generator.
 *
 * @return The destination generator.
 */
extern GAGenerator *ga_generator_copy(GAGenerator *dest, const GAGenerator *src);

/**
 * @brief Write a generator to a stream.
 *
 * @param generator The generator.
 * @param stream The stream.
 *
 * @return The generator.
 */
extern GAGenerator *ga_generator_fwrite(const GAGenerator *generator, FILE *stream);
/**
 * @brief Read a generator from a stream.
 *
 * @param generator The generator.
 * @param stream The stream.
 *
 * @return The generator.
 */
extern GAGenerator *ga_generator_fread(GAGenerator *generator, FILE *stream);

/**
 * @brief Convert a generator to a string.
 *
 * @param generator The generator.
 *
 * @return The string.
 */
extern const char *ga_generator_to_string(const GAGenerator *generator);

/**
 * @brief Generate a random individual.
 *
 * @details Generate a random individual using the given generator.
 * @details The individual is initialized with all values set to random values.
 *
 * @param data The individual.
 * @param generator The generator.
 *
 * @note The individual must have the same size as the generator.
 * @note The individual is initialized.
 */
extern void ga_generator_random(unsigned int *data, const GAGenerator *generator);
/**
 * @brief Mutate an individual.
 *
 * @details Mutate an individual using the given generator.
 * @details The individual is mutated with the given probability.
 *
 * @param data The individual.
 * @param generator The generator.
 * @param probability The probability.
 *
 * @note The individual must have the same size as the generator.
 * @note The probability must be between 0 and 1.
 * @note The individual must be initialized.
 * @note The individual is mutated in place.
 *
 * @see ga_generator_random
 * @see ga_generator_crossover
 */
extern void ga_generator_mutation(unsigned int *data, const GAGenerator *generator, double probability);
/**
 * @brief Crossover two individuals.
 *
 * @details Crossover two individuals using the given generator.
 * @details The individuals are crossed over with the given probability.
 * @details The individuals must have the same size.
 *
 * @param data1 The first individual.
 * @param data2 The second individual.
 * @param generator The generator.
 * @param probability The probability.
 *
 * @note The probability must be between 0 and 1.
 * @note The individuals must be initialized.
 * @note The individuals are crossed over in place.
 *
 * @see ga_generator_random
 * @see ga_generator_mutation
 */
extern void ga_generator_crossover(unsigned int *data1, unsigned int *data2, const GAGenerator *generator, double probability);
/**
 * @brief Duplicate an individual.
 *
 * @param dest The destination individual.
 * @param src The source individual.
 * @param generator The generator.
 *
 * @note The destination individual must have the same size as the generator.
 * @note The source individual must have the same size as the generator.
 * @note The destination individual is initialized.
 * @note The source individual must be initialized.
 * @note The destination individual is duplicated in place.
 *
 * @see ga_generator_random
 */
extern void ga_generator_duplicate(unsigned int *dest, unsigned int *src, const GAGenerator *generator);

/**
 * @brief The GAAlgorithm structure.
 *
 * @details The GAAlgorithm structure is used to represent an algorithm.
 */
typedef struct _GAAlgorithm GAAlgorithm;

/**
 * @brief Create a new algorithm.
 *
 * @param generator The generator.
 * @param context The context.
 * @param mutation_rate The mutation rate.
 * @param crossover_rate The crossover rate.
 * @param size The size of the population.
 * @param fitness The fitness function.
 *
 * @return The new algorithm.
 *
 * @note The returned algorithm must be destroyed with ga_algorithm_destroy.
 * @note The fitness function must return the fitness of the given individual.
 * @note The fitness function must be deterministic.
 *
 * @see ga_algorithm_destroy
 */
extern GAAlgorithm *ga_algorithm_create(const GAGenerator *generator, const void *context, double mutation_rate, double crossover_rate,
                                        unsigned int size, unsigned int (*fitness)(const unsigned int *, const GAGenerator *, const void *));
/**
 * @brief Destroy an algorithm.
 *
 * @param algorithm The algorithm.
 *
 * @note The algorithm must not be used after calling this function.
 *
 * @see ga_algorithm_create
 */
extern void ga_algorithm_destroy(GAAlgorithm *algorithm);
/**
 * @brief Get the generator of an algorithm.
 *
 * @param algorithm The algorithm.
 *
 * @return The generator.
 *
 * @see ga_algorithm_set_generator
 */
extern const GAGenerator *ga_algorithm_get_generator(const GAAlgorithm *algorithm);
/**
 * @brief Set the generator of an algorithm.
 *
 * @param algorithm The algorithm.
 * @param generator The generator.
 *
 * @return The algorithm.
 *
 * @see ga_algorithm_get_generator
 */
extern GAAlgorithm *ga_algorithm_set_generator(GAAlgorithm *algorithm, const GAGenerator *generator);
/**
 * @brief Get the context of an algorithm.
 *
 * @param algorithm The algorithm.
 *
 * @return The context.
 *
 * @see ga_algorithm_set_context
 */
extern const void *ga_algorithm_get_context(const GAAlgorithm *algorithm);
/**
 * @brief Set the context of an algorithm.
 *
 * @param algorithm The algorithm.
 * @param context The context.
 *
 * @return The algorithm.
 *
 * @see ga_algorithm_get_context
 */
extern GAAlgorithm *ga_algorithm_set_context(GAAlgorithm *algorithm, const void *context);
/**
 * @brief Get the mutation rate of an algorithm.
 *
 * @param algorithm The algorithm.
 *
 * @return The mutation rate.
 *
 * @see ga_algorithm_set_mutation_rate
 */
extern double ga_algorithm_get_mutation_rate(const GAAlgorithm *algorithm);
/**
 * @brief Set the mutation rate of an algorithm.
 *
 * @param algorithm The algorithm.
 * @param mutation_rate The mutation rate.
 *
 * @return The algorithm.
 *
 * @note The mutation rate must be between 0 and 1.
 *
 * @see ga_algorithm_get_mutation_rate
 */
extern GAAlgorithm *ga_algorithm_set_mutation_rate(GAAlgorithm *algorithm, double mutation_rate);
/**
 * @brief Get the crossover rate of an algorithm.
 *
 * @param algorithm The algorithm.
 *
 * @return The crossover rate.
 *
 * @see ga_algorithm_set_crossover_rate
 */
extern double ga_algorithm_get_crossover_rate(const GAAlgorithm *algorithm);
/**
 * @brief Set the crossover rate of an algorithm.
 *
 * @param algorithm The algorithm.
 * @param crossover_rate The crossover rate.
 *
 * @return The algorithm.
 *
 * @note The crossover rate must be between 0 and 1.
 *
 * @see ga_algorithm_get_crossover_rate
 */
extern GAAlgorithm *ga_algorithm_set_crossover_rate(GAAlgorithm *algorithm, double crossover_rate);
/**
 * @brief Get the population size of an algorithm.
 *
 * @param algorithm The algorithm.
 *
 * @return The population size.
 *
 * @see ga_algorithm_set_size
 */
extern unsigned int ga_algorithm_get_size(const GAAlgorithm *algorithm);
/**
 * @brief Set the population size of an algorithm.
 *
 * @param algorithm The algorithm.
 * @param size The population size.
 *
 * @return The algorithm.
 *
 * @note The population size must be greater than 0.
 *
 * @see ga_algorithm_get_size
 */
extern GAAlgorithm *ga_algorithm_set_size(GAAlgorithm *algorithm, unsigned int size);
/**
 * @brief Get the fitness function of an algorithm.
 *
 * @param algorithm The algorithm.
 *
 * @return The fitness function.
 */
extern unsigned int (*ga_algorithm_get_fitness(const GAAlgorithm *algorithm))(const unsigned int *, const GAGenerator *, const void *);  // NOLINT whitespace/parens
/**
 * @brief Set the fitness function of an algorithm.
 *
 * @param algorithm The algorithm.
 * @param fitness The fitness function.
 *
 * @return The algorithm.
 *
 * @note The fitness function must return the fitness of the given individual.
 * @note The fitness function must be deterministic.
 *
 * @see ga_algorithm_get_fitness
 */
extern GAAlgorithm *ga_algorithm_set_fitness(GAAlgorithm *algorithm,
                                             unsigned int (*fitness)(const unsigned int *, const GAGenerator *, const void *));

/**
 * @brief The GAIndividual structure.
 *
 * @details The GAIndividual structure is used to represent an individual.
 */
typedef struct _GAIndividual GAIndividual;

/**
 * @brief Create a new population.
 *
 * @details Create a new population of the given size.
 *
 * @param algorithm The algorithm.
 *
 * @return The new population.
 *
 * @note The returned population must be destroyed with ga_population_destroy.
 *
 * @see ga_population_destroy
 */
extern GAIndividual *ga_population_create(const GAAlgorithm *algorithm);
/**
 * @brief Destroy a population.
 *
 * @param population The population.
 *
 * @see ga_population_create
 */
extern void ga_population_destroy(GAIndividual *population, const GAAlgorithm *algorithm);
/**
 * @brief Get the individual at the given index.
 * @param population The population.
 * @param index The index.
 * @return The individual.
 */
extern GAIndividual *ga_population_get(const GAIndividual *population, unsigned int index);
/**
 * @brief Get the fitness of an individual
 *
 * @param individual The individual.
 *
 * @return The fitness.
 *
 * @see ga_individual_get_data
 */
extern unsigned int ga_individual_get_fitness(const GAIndividual *individual);
/**
 * @brief Get the data of an individual
 *
 * @param individual The individual.
 *
 * @return The data.
 *
 * @see ga_individual_get_fitness
 */
extern unsigned int *ga_individual_get_data(const GAIndividual *individual);
/**
 * @brief Fill a population using random values.
 *
 * @param population The population.
 * @param algorithm The algorithm.
 *
 * @return The population.
 *
 * @see ga_population_evaluate
 */
extern GAIndividual *ga_population_random(GAIndividual *population, const GAAlgorithm *algorithm);
/**
 * @brief Evaluate a population.
 *
 * @param population The population.
 * @param algorithm The algorithm.
 *
 * @return The population.
 *
 * @see ga_population_random
 */
extern GAIndividual *ga_population_evaluate(GAIndividual *population, const GAAlgorithm *algorithm);
/**
 * @brief Sort a population.
 *
 * @param population The population.
 * @param algorithm The algorithm.
 *
 * @return The population.
 *
 * @see ga_population_evaluate
 */
extern GAIndividual *ga_population_sort(GAIndividual *population, const GAAlgorithm *algorithm);
/**
 * @brief Get the next population.
 *
 * @param dest The destination population.
 * @param src The source population.
 * @param algorithm The algorithm.
 *
 * @return The destination population.
 */
extern GAIndividual *ga_population_next(GAIndividual *dest, const GAIndividual *src, const GAAlgorithm *algorithm);

#endif  // GENETIC_ALGORITHM_H_
