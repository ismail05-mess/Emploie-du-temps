/**
 * @file solve.c
 *
 * @author     Christophe Demko <christophe.demko@univ-lr.fr>
 * @date       2019-2023
 * @copyright  BSD 3-Clause License
 */

/**
 * After unzipping in $HOME/.local, execute with
 * $ LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$HOME/.local/lib" ~/.local/bin/solve
 */
#include <stdlib.h>
#include <time.h>

#include "./genetic-algorithm.h"

typedef struct _Context Context;
struct _Context {
  double precision;
};

double convert(const unsigned int *data, const GAGenerator *generator, const Context *context) {
  int accumulate = 0;
  for (unsigned int index = 1; index < ga_generator_get_size(generator); index++) {
    accumulate *= 2;
    accumulate += data[index];
  }
  if (data[0]) {
    accumulate *= -1;
  }
  return accumulate * context->precision;
}

// Evaluate the fitness of an individual to solve x3 + 3x2 − 6x − 8 = 0 (x in {-4, -1, 2})
unsigned int fitness(const unsigned int *data, const GAGenerator *generator, Context *context) {
  double x = convert(data, generator, context);
  double y = x * x * x + 3 * x * x - 6 * x - 8;
  return (unsigned int)(1 / (y * y + 0.0000001));
}

int main(void) {
  srand(time(NULL));
  ga_init();
  // Precision set to 1e-2
  Context context = {.precision = 1e-2};
  {
    FILE * stream = stdout;
    GAGenerator *generator = ga_generator_create(10);
    for (unsigned domain = 0; domain < ga_generator_get_size(generator); domain++) {
      ga_generator_set_domain(generator, domain, 2);
    }
    {
      GAAlgorithm *algorithm =
          ga_algorithm_create(generator, &context, 0.01, 0.8, 50, (unsigned int (*)(const unsigned int *, const GAGenerator *, const void *))fitness);
      {
        GAIndividual *population = ga_population_create(algorithm);
        population = ga_population_random(population, algorithm);
        GAIndividual *next = ga_population_create(algorithm);
        for (unsigned int index = 0; index < 1000; index++) {
          population = ga_population_evaluate(population, algorithm);
          population = ga_population_sort(population, algorithm);
          double sum = 0.0;
          for (unsigned int individual = 0; individual < ga_algorithm_get_size(algorithm); individual++) {
            sum += ga_individual_get_fitness(ga_population_get(population, individual));
          }
          printf("Average fitness: %f\n", sum / ga_algorithm_get_size(algorithm));
          next = ga_population_next(next, population, algorithm);
          GAIndividual *tmp = population;
          population = next;
          next = tmp;
        }

        population = ga_population_evaluate(population, algorithm);
        population = ga_population_sort(population, algorithm);
        fprintf(stream, "%f\n", convert(ga_individual_get_data(ga_population_get(population, 0)), generator, &context));

        ga_population_destroy(population, algorithm);
        ga_population_destroy(next, algorithm);
      }
      ga_algorithm_destroy(algorithm);
    }
    ga_generator_destroy(generator);
  }
  ga_finish();
  return EXIT_SUCCESS;
}
