/**
 * @file bitset.h
 *
 * @author     Christophe Demko <christophe.demko@univ-lr.fr>
 * @date       2007-2023
 * @copyright  BSD 3-Clause License
 */

#ifndef BITSET_H_
#define BITSET_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>

/**
 * @brief The bitset memory allocation function.
 */
extern void *(*bitset_malloc)(size_t size);
/**
 * @brief The bitset memory array like allocation function.
 */
extern void *(*bitset_calloc)(size_t nmemb, size_t size);
/**
 * @brief The bitset memory reallocation function.
 */
extern void *(*bitset_realloc)(void *ptr, size_t size);
/**
 * @brief The bitset memory free function.
 */
extern void (*bitset_free)(void *ptr);

/**
 * @brief The bitset type.
 *
 * @note The bitset type is opaque, i.e. its definition is hidden from the user.
 * @see bitset_create
 * @see bitset_destroy
 */
typedef struct _BitSet BitSet;

/**
 * @brief Initialize the bitset module.
 *
 * @return True if the module was initialized successfully, false otherwise.
 *
 * @note This function must be called before any other function in the module.
 * @note This function can be called multiple times, but must be called the same number of times as bitset_finish.
 */
extern bool bitset_init(void);
/**
 * @brief Finalize the bitset module.
 *
 * @return True if the module was finalized successfully, false otherwise.
 *
 * @note This function must be called after all other functions in the module.
 * @note This function can be called multiple times, but must be called the same number of times as bitset_init.
 */
extern bool bitset_finish(void);

/**
 * @brief Create a new bitset.
 *
 * @param size The size of the bitset in bits.
 *
 * @return A pointer to the new bitset, or NULL if an error occurred.
 *
 * @note All bits in the bitset are set to false.
 */
extern BitSet *bitset_create(size_t size);
/**
 * @brief Clone a bitset.
 *
 * @param src The bitset to clone.
 *
 * @return A pointer to the new bitset, or NULL if an error occurred.
 *
 * @note The new bitset has the same size as the source bitset.
 */
extern BitSet *bitset_clone(const BitSet *src);
/**
 * @brief Destroy a bitset.
 *
 * @param bits The bitset to destroy.
 *
 * @note This function frees the memory allocated for the bitset.
 *
 * @see bitset_create
 * @see bitset_copy
 */
extern void bitset_destroy(BitSet *bits);

/**
 * @brief Get the value of a bit in a bitset.
 *
 * @param bits The bitset.
 * @param index The index of the bit to get.
 *
 * @return The value of the bit.
 *
 * @note The index must be less than the size of the bitset.
 *
 * @see bitset_set_value
 */
extern bool bitset_get_value(const BitSet *bits, unsigned int index);
/**
 * @brief Set the value of a bit in a bitset.
 *
 * @param bits The bitset.
 * @param index The index of the bit to set.
 * @param value The value to set the bit to.
 *
 * @return The bitset.
 *
 * @note The index must be less than the size of the bitset.
 *
 * @see bitset_get_value
 */
extern BitSet *bitset_set_value(BitSet *bits, unsigned int index, bool value);
/**
 * @brief Set the value of a bit in a bitset to true.
 *
 * @param bits The bitset.
 * @param index The index of the bit to set.
 *
 * @return The bitset.
 *
 * @note The index must be less than the size of the bitset.
 *
 * @see bitset_set_false
 * @see bitset_set_value
 */
extern BitSet *bitset_set_true(BitSet *bits, unsigned int index);
/**
 * @brief Set the value of a bit in a bitset to false.
 *
 * @param bits The bitset.
 * @param index The index of the bit to set.
 *
 * @return The bitset.
 *
 * @note The index must be less than the size of the bitset.
 *
 * @see bitset_set_true
 * @see bitset_set_value
 */
extern BitSet *bitset_set_false(BitSet *bits, unsigned int index);

/**
 * @brief Clear a bitset.
 *
 * @param bits The bitset to clear.
 *
 * @return The bitset.
 *
 * @note This function sets all bits in the bitset to false.
 *
 * @see bitset_set_false
 */
extern BitSet *bitset_clear(BitSet *bits);
/**
 * @brief Copy a bitset.
 *
 * @param dest The destination bitset.
 * @param src The source bitset.
 *
 * @return The destination bitset.
 *
 * @note The destination bitset must be the same size as the source bitset.
 *
 * @see bitset_clone
 */
extern BitSet *bitset_copy(BitSet *dest, const BitSet *src);
/**
 * @brief Complement a bitset.
 *
 * @param result The result bitset.
 * @param src The source bitset.
 *
 * @return The result bitset.
 *
 * @note The result bitset must be the same size as the source bitset.
 */
extern BitSet *bitset_complement(BitSet *result, const BitSet *src);
/**
 * @brief Complement a bitset.
 *
 * @param bits The bitset.
 *
 * @return The bitset.
 *
 * @see bitset_complement
 *
 */
extern BitSet *bitset_complement_update(BitSet *bits);
/**
 * @brief Union two bitsets.
 *
 * @param result The result bitset.
 * @param a The first bitset.
 * @param b The second bitset.
 *
 * @return The result bitset.
 *
 * @note The result bitset must be the same size as the source bitsets.
 *
 * @see bitset_intersection
 */
extern BitSet *bitset_union(BitSet *result, const BitSet *a, const BitSet *b);
/**
 * @brief Union two bitsets.
 *
 * @param bits The bitset.
 * @param other The other bitset.
 *
 * @return The bitset.
 *
 * @note The bitset must be the same size as the other bitset.
 *
 * @see bitset_union
 */
extern BitSet *bitset_union_update(BitSet *bits, const BitSet *other);
/**
 * @brief Intersect two bitsets.
 *
 * @param result The result bitset.
 * @param a The first bitset.
 * @param b The second bitset.
 *
 * @return The result bitset.
 *
 * @note The result bitset must be the same size as the source bitsets.
 *
 * @see bitset_union
 */
extern BitSet *bitset_intersection(BitSet *result, const BitSet *a, const BitSet *b);
/**
 * @brief Intersect two bitsets.
 *
 * @param bits The bitset.
 * @param other The other bitset.
 *
 * @return The bitset.
 *
 * @note The bitset must be the same size as the other bitset.
 *
 * @see bitset_intersection
 */
extern BitSet *bitset_intersection_update(BitSet *bits, const BitSet *other);
/**
 * @brief Compute the difference of two bitsets.
 *
 * @param result The result bitset.
 * @param a The first bitset.
 * @param b The second bitset.
 *
 * @return The result bitset.
 *
 * @note The result bitset must be the same size as the source bitsets.
 *
 * @see bitset_union
 * @see bitset_intersection
 * @see bitset_difference
 */
extern BitSet *bitset_difference(BitSet *result, const BitSet *a, const BitSet *b);
/**
 * @brief Compute the difference of two bitsets.
 *
 * @param bits The bitset.
 * @param other The other bitset.
 *
 * @return The bitset.
 *
 * @note The bitset must be the same size as the other bitset.
 *
 * @see bitset_difference
 */
extern BitSet *bitset_difference_update(BitSet *bits, const BitSet *other);
/**
 * @brief Compute the symmetric difference of two bitsets.
 *
 * @param result The result bitset.
 * @param a The first bitset.
 * @param b The second bitset.
 *
 * @return The result bitset.
 *
 * @note The result bitset must be the same size as the source bitsets.
 *
 * @see bitset_union
 * @see bitset_intersection
 * @see bitset_difference
 */
extern BitSet *bitset_symmetric_difference(BitSet *result, const BitSet *a, const BitSet *b);
/**
 * @brief Compute the symmetric difference of two bitsets.
 *
 * @param bits The bitset.
 * @param other The other bitset.
 *
 * @return The bitset.
 *
 * @note The bitset must be the same size as the other bitset.
 *
 * @see bitset_symmetric_difference
 */
extern BitSet *bitset_symmetric_difference_update(BitSet *bits, const BitSet *other);

/**
 * @brief Get the cardinality of a bitset.
 *
 * @param bits The bitset.
 *
 * @return The cardinality of the bitset in bits.
 *
 * @note The cardinality of a bitset is the number of bits set to true.
 *
 * @see bitset_is_empty
 * @see bitset_is_singleton
 */
extern unsigned int bitset_cardinality(const BitSet *bits);

/**
 * @brief Check if a bitset is empty.
 *
 * @param bits The bitset.
 *
 * @return True if the bitset is empty, false otherwise.
 *
 * @note A bitset is empty if all bits are set to false.
 *
 * @see bitset_cardinality
 */
extern bool bitset_is_empty(const BitSet *bits);
/**
 * @brief Check if a bitset is a singleton.
 *
 * @param bits The bitset.
 *
 * @return True if the bitset is a singleton, false otherwise.
 *
 * @note A bitset is a singleton if it has exactly one bit set to true.
 *
 * @see bitset_cardinality
 */
extern bool bitset_is_singleton(const BitSet *bits);

/**
 * @brief Check if two bitsets are equal.
 *
 * @param bits The first bitset.
 * @param other The second bitset.
 *
 * @return True if the bitsets are equal, false otherwise.
 *
 * @note Two bitsets are equal if they have the same size and the same bits set to true.
 *
 * @see bitset_is_subset
 */
extern bool bitset_equals(const BitSet *bits, const BitSet *other);
/**
 * @brief Check if a bitset is a subset of another bitset.
 *
 * @param bits The first bitset.
 * @param other The second bitset.
 *
 * @return True if the first bitset is a subset of the second bitset, false otherwise.
 *
 * @note A bitset is a subset of another bitset if all bits set to true in the first bitset are also set to true in the second bitset.
 *
 * @see bitset_is_subset_strict
 * @see bitset_equals
 */
extern bool bitset_is_subset(const BitSet *bits, const BitSet *other);
/**
 * @brief Check if a bitset is a strict subset of another bitset.
 *
 * @param bits The first bitset.
 * @param other The second bitset.
 *
 * @return True if the first bitset is a strict subset of the second bitset, false otherwise.
 *
 * @note A bitset is a strict subset of another bitset
 *       if all bits set to true in the first bitset are also set to true in the second bitset
 *       and the first bitset is not equal to the second bitset.
 *
 * @see bitset_is_subset
 */
extern bool bitset_is_subset_strict(const BitSet *bits, const BitSet *other);
/**
 * @brief Check if two bitsets intersect.
 *
 * @param bits The first bitset.
 * @param other The second bitset.
 *
 * @return True if the bitsets intersect, false otherwise.
 *
 * @note Two bitsets intersect if they have at least one bit set to true in common.
 *
 * @see bitset_is_subset
 */
extern bool bitset_intersects(const BitSet *bits, const BitSet *other);

/**
 * @brief Write a bitset to a stream.
 *
 * @param bits The bitset.
 * @param stream The stream.
 *
 * @return The bitset.
 */
extern BitSet *bitset_fwrite(const BitSet *bits, FILE *stream);
/**
 * @brief Read a bitset from a stream.
 *
 * @param bits The bitset.
 * @param stream The stream.
 *
 * @return The bitset.
 */
extern BitSet *bitset_fread(BitSet *bits, FILE *stream);

/**
 * @brief Convert a bitset to a string.
 *
 * @param bits The bitset.
 *
 * @return A string representation of the bitset.
 *
 * @note The string representation of a bitset is a sequence of 0s and 1s.
 * @note The returned string is allocated by the function and must not be freed.
 */
extern const char *bitset_to_string(const BitSet *bits);

#endif  // BITSET_H_
