/**
 * @file teaching-slot.h
 *
 * @author     Christophe Demko <christophe.demko@univ-lr.fr>
 * @date       2023-2023
 * @copyright  BSD 3-Clause License
 */

#ifndef TEACHING_SLOT_H_
#define TEACHING_SLOT_H_

#include <stdbool.h>
#include <stdio.h>

/**
 * @brief The TeachingSlot memory allocation function.
 */
extern void *(*teaching_slot_malloc)(size_t size);
/**
 * @brief The TeachingSlot memory array like allocation function.
 */
extern void *(*teaching_slot_calloc)(size_t nmemb, size_t size);
/**
 * @brief The TeachingSlot memory reallocation function.
 */
extern void *(*teaching_slot_realloc)(void *ptr, size_t size);
/**
 * @brief The TeachingSlot memory free function.
 */
extern void (*teaching_slot_free)(void *ptr);

/**
 * @brief The TeachingSlot structure
 *
 * @note This structure is opaque, its fields should not be accessed directly
 */
typedef struct _TeachingSlot TeachingSlot;

/**
 * @brief Initialize the TeachingSlot module
 *
 * @return true on success, false on error
 *
 * @note This function must be called before any other function in the module.
 * @note This function can be called multiple times, but must be called the same number of times as teaching_slot_finish.
 *
 * @see teaching_slot_finish
 */
extern bool teaching_slot_init(void);
/**
 * @brief Finalize the TeachingSlot module
 *
 * @return true on success, false on error
 *
 * @note This function must be called after all other functions in the module.
 * @note This function can be called multiple times, but must be called the same number of times as teaching_slot_init.
 *
 * @see teaching_slot_init
 */
extern bool teaching_slot_finish(void);

/**
 * @brief Create a new TeachingSlot item
 *
 * @param size the number of groups
 *
 * @return a pointer to the new TeachingSlot item
 *
 * @see teaching_slot_destroy
 */
extern TeachingSlot *teaching_slot_create(size_t size);
/**
 * @brief Destroy a TeachingSlot item
 *
 * @param slot the TeachingSlot item to destroy
 *
 * @see teaching_slot_create
 */
extern void teaching_slot_destroy(TeachingSlot *slot);

/**
 * @brief Get the size of a TeachingSlot item
 * 
 * @param slot the TeachingSlot item
 * 
 * @return the size
 */
extern size_t teaching_slot_get_size(const TeachingSlot *slot);
/**
 * @brief Get a group of a TeachingSlot item
 * 
 * @param slot the TeachingSlot item
 * @param group the group index
 * 
 * @return the group
 * @see teaching_slot_set_group
 */
extern unsigned int teaching_slot_get_group(const TeachingSlot *slot, unsigned int group);
/**
 * @brief Set a group of a TeachingSlot item
 *  
 * @param slot the TeachingSlot item
 * @param group the group index
 * @param value the group value
 * 
 * @return the TeachingSlot item
 * @see teaching_slot_get_group 
 */
extern TeachingSlot *teaching_slot_set_group(TeachingSlot *slot, unsigned int group, unsigned int value);

/**
 * @brief Copy a TeachingSlot item
 *
 * @param dest the destination TeachingSlot item
 * @param src the source TeachingSlot item
 *
 * @return the destination TeachingSlot item
 *
 * @see teaching_slot_clone
 */
extern TeachingSlot *teaching_slot_copy(TeachingSlot *dest, const TeachingSlot *src);
/**
 * @brief Clone a TeachingSlot item
 *
 * @param src the source TeachingSlot item
 *
 * @return the cloned TeachingSlot item
 *
 * @see teaching_slot_copy
 */
extern TeachingSlot *teaching_slot_clone(const TeachingSlot *src);

/**
 * @brief Write a TeachingSlot item to a stream
 *
 * @param slot the TeachingSlot item
 * @param stream the stream
 *
 * @return the TeachingSlot item
 *
 * @see teaching_slot_fread
 */
extern TeachingSlot *teaching_slot_fwrite(const TeachingSlot *slot, FILE *stream);
/**
 * @brief Read a TeachingSlot item from a stream
 *
 * @param slot the TeachingSlot item
 * @param stream the stream
 *
 * @return the TeachingSlot item
 *
 * @see teaching_slot_fwrite
 */
extern TeachingSlot *teaching_slot_fread(TeachingSlot *slot, FILE *stream);

/**
 * @brief Convert a TeachingSlot to a string.
 *
 * @param slot The TeachingSlot item.
 *
 * @return A string representation of the TeachingSlot item.
 *
 * @note The returned string is statically allocated and must not be freed.
 */
extern const char *teaching_slot_to_string(const TeachingSlot *slot);

#endif  // TEACHING_SLOT_H_
