/**
 * @file space-time-slot.h
 *
 * @author     Christophe Demko <christophe.demko@univ-lr.fr>
 * @date       2023-2023
 * @copyright  BSD 3-Clause License
 */

#ifndef SPACE_TIME_SLOT_H_
#define SPACE_TIME_SLOT_H_

#include <stdbool.h>
#include <stdio.h>
#include <time.h>

/**
 * @brief The SpaceTimeSlot memory allocation function.
 */
extern void *(*space_time_slot_malloc)(size_t size);
/**
 * @brief The SpaceTimeSlot memory array like allocation function.
 */
extern void *(*space_time_slot_calloc)(size_t nmemb, size_t size);
/**
 * @brief The SpaceTimeSlot memory reallocation function.
 */
extern void *(*space_time_slot_realloc)(void *ptr, size_t size);
/**
 * @brief The SpaceTimeSlot memory free function.
 */
extern void (*space_time_slot_free)(void *ptr);

/**
 * @brief The SpaceTimeSlot structure
 *
 * @note This structure is opaque, its fields should not be accessed directly
 */
typedef struct _SpaceTimeSlot SpaceTimeSlot;

/**
 * @brief Initialize the SpaceTimeSlot module
 *
 * @return true on success, false on error
 *
 * @note This function must be called before any other function in the module.
 * @note This function can be called multiple times, but must be called the same number of times as space_time_slot_finish.
 *
 * @see space_time_slot_finish
 */
extern bool space_time_slot_init(void);
/**
 * @brief Finalize the SpaceTimeSlot module
 *
 * @return true on success, false on error
 *
 * @note This function must be called after all other functions in the module.
 * @note This function can be called multiple times, but must be called the same number of times as space_time_slot_init.
 *
 * @see space_time_slot_init
 */
extern bool space_time_slot_finish(void);

/**
 * @brief Create a new SpaceTimeSlot item
 *
 * @param start the start time
 * @param end the end time
 * @param room the room number
 *
 * @return a pointer to the new SpaceTimeSlot item
 *
 * @note The start time must be strictly less than the end time
 * @see space_time_slot_destroy
 */
extern SpaceTimeSlot *space_time_slot_create(time_t start, time_t end, unsigned int room);
/**
 * @brief Destroy a SpaceTimeSlot item
 *
 * @param slot the SpaceTimeSlot item to destroy
 *
 * @see space_time_slot_create
 */
extern void space_time_slot_destroy(SpaceTimeSlot *slot);

/**
 * @brief Get the start time of a SpaceTimeSlot item
 *
 * @param slot the SpaceTimeSlot item
 *
 * @return the start time
 *
 * @see space_time_slot_get_end
 */
extern time_t space_time_slot_get_start(const SpaceTimeSlot *slot);
/**
 * @brief Get the end time of a SpaceTimeSlot item
 *
 * @param slot the SpaceTimeSlot item
 *
 * @return the end time
 *
 * @see space_time_slot_get_start
 */
extern time_t space_time_slot_get_end(const SpaceTimeSlot *slot);
/**
 * @brief Get the room number of a SpaceTimeSlot item
 *
 * @param slot the SpaceTimeSlot item
 *
 * @return the room number
 *
 * @see space_time_slot_set_room
 */
extern unsigned int space_time_slot_get_room(const SpaceTimeSlot *slot);
/**
 * @brief Set the start and end time of a SpaceTimeSlot item
 *
 * @param slot the SpaceTimeSlot item
 * @param start the start time
 * @param end the end time
 *
 * @return the SpaceTimeSlot item
 *
 * @note The start time must be strictly less than the end time
 * @see space_time_slot_set_room
 */
extern SpaceTimeSlot *space_time_slot_set_time(SpaceTimeSlot *slot, time_t start, time_t end);
/**
 * @brief Set the room number of a SpaceTimeSlot item
 *
 * @param slot the SpaceTimeSlot item
 * @param room the room number
 *
 * @return the SpaceTimeSlot item
 *
 * @see space_time_slot_set_time
 */
extern SpaceTimeSlot *space_time_slot_set_room(SpaceTimeSlot *slot, unsigned int room);

/**
 * @brief Copy a SpaceTimeSlot item
 *
 * @param dest the destination SpaceTimeSlot item
 * @param src the source SpaceTimeSlot item
 *
 * @return the destination SpaceTimeSlot item
 *
 * @see space_time_slot_clone
 */
extern SpaceTimeSlot *space_time_slot_copy(SpaceTimeSlot *dest, const SpaceTimeSlot *src);
/**
 * @brief Clone a SpaceTimeSlot item
 *
 * @param src the source SpaceTimeSlot item
 *
 * @return the cloned SpaceTimeSlot item
 *
 * @see space_time_slot_copy
 */
extern SpaceTimeSlot *space_time_slot_clone(const SpaceTimeSlot *src);

/**
 * @brief Write a SpaceTimeSlot item to a stream
 *
 * @param stream the stream
 *
 * @return the SpaceTimeSlot item
 *
 * @see space_time_slot_fread
 */
extern SpaceTimeSlot *space_time_slot_fwrite(const SpaceTimeSlot *slot, FILE *stream);
/**
 * @brief Read a SpaceTimeSlot item from a stream
 *
 * @param stream the stream
 *
 * @return the SpaceTimeSlot item
 *
 * @see space_time_slot_fwrite
 */
extern SpaceTimeSlot *space_time_slot_fread(SpaceTimeSlot *slot, FILE *stream);

/**
 * @brief Convert a SpaceTimeSlot to a string.
 *
 * @param slot The SpaceTimeSlot item.
 *
 * @return A string representation of the SpaceTimeSlot item.
 *
 * @note The returned string is statically allocated and must not be freed.
 */
extern const char *space_time_slot_to_string(const SpaceTimeSlot *slot);

#endif  // SPACE_TIME_SLOT_H_
